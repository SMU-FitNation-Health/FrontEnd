import React, { useState } from "react";
import DailyHeader from "../../dailyfood/components/DailyHeader";
import {
  ReFoodTabs,
  ReFoodTitle,
  IngredientInputCard,
  TipsCard,
  RecipeResultsSection,
  ConveniencePlaceholder,
} from "./components";
import { MOCK_RECIPES } from "./data/mockRecipes";
import Footer from "../../../layout/footer/Footer.jsx";
import useReFoodSearch from "./hooks/useReFoodSearch";

export default function ReFoodPage() {
  const [tab, setTab] = useState("fridge");

  const {
    items,
    results,
    searched,
    addItem,
    removeItem,
    search,
  } = useReFoodSearch(MOCK_RECIPES);

  const fridgeContent = (
    <>
      <IngredientInputCard
        items={items}
        onAdd={addItem}
        onRemove={removeItem}
        onSearch={search}
      />
      <RecipeResultsSection searched={searched} results={results} />
      <TipsCard />
    </>
  );

  const convenienceContent = (
    <>
      <ConveniencePlaceholder />
      <TipsCard />
    </>
  );

  return (
    <div className="w-full min-h-dvh bg-[#F9FAFB] overflow-x-hidden">
      <DailyHeader />

      <main className="w-full max-w-[1440px] mx-auto px-[clamp(12px,3vw,40px)] py-[clamp(18px,4vw,60px)] space-y-[clamp(14px,3vmin,24px)]">
        <ReFoodTitle />

        <ReFoodTabs value={tab} onChange={setTab} />

        {tab === "fridge" ? fridgeContent : convenienceContent}
      </main>

      <Footer />
    </div>
  );
}
