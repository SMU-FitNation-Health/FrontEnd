import React, { useState } from "react";
import DailyHeader from "../dailyfood/components/DailyHeader";
import Footer from "../../layout/footer/Footer.jsx";

import ReFoodPage from "./refood/ReFoodPage";
import MarketFoodPage from "./marketfood/MarketFoodPage";

// 상위 탭(냉장고/편의점) - FoodPage에서만 사용
function FoodTopTabs({ value, onChange }) {
  const tabBtn = (key, label) => {
    const active = value === key;
    return (
      <button
        key={key}
        type="button"
        onClick={() => onChange(key)}
        className={`rounded-full px-[clamp(12px,2.2vmin,18px)] py-[clamp(6px,1.4vmin,10px)] font-semibold transition
          ${active ? "bg-[#1E2939] text-white" : "bg-white/70 text-[#1E2939] border border-[#D1D5DC] hover:bg-white"}`}
        style={{ fontSize: "clamp(12px,1.6vmin,15px)" }}
      >
        {label}
      </button>
    );
  };

  return (
    <div className="flex items-center gap-[clamp(6px,1.4vmin,10px)]">
      {tabBtn("fridge", "냉장고 조합")}
      {tabBtn("convenience", "편의점 조합")}
    </div>
  );
}

export default function FoodPage() {
  const [tab, setTab] = useState("fridge"); // fridge | convenience

  return (
    <div className="w-full min-h-dvh bg-[#F9FAFB] overflow-x-hidden">
      <DailyHeader />

      <main className="w-full max-w-[1440px] mx-auto px-[clamp(12px,3vw,40px)] py-[clamp(18px,4vw,60px)] space-y-[clamp(14px,3vmin,24px)]">
        {/* ✅ 공용 문구/타이틀 자리 (너가 말한 공용 컴포넌트 쓰면 여기 꽂으면 됨) */}
        {/* 예: <ReFoodTitle /> 또는 <FoodTitle /> */}
        
        {/* 상위 탭 */}
        <FoodTopTabs value={tab} onChange={setTab} />

        {/* 페이지 스위칭 */}
        {tab === "fridge" ? (
          <ReFoodPage embedded />
        ) : (
          <MarketFoodPage embedded />
        )}
      </main>

      <Footer />
    </div>
  );
}
